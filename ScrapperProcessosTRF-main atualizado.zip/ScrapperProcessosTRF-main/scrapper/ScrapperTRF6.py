import requests as req
from bs4 import BeautifulSoup as bs
from time import sleep
import re
from typing import List

class ScrapperTRF6:
    uri = 'https://pje1g.trf6.jus.br/consultapublica/ConsultaPublica/DetalheProcessoConsultaPublica/listView.seam'
    @staticmethod
    def limpa_url(url):
        url = url.strip('openPopUp(\'Consulta pública\',\'').strip('\')')
        url = 'https://pje1g.trf6.jus.br' + url
        return url

    def get_urls(self, cnpj):
        headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
        }
        cnpj_fmt = self.formata_cnpj(cnpj)
        
        data = {
            
            'AJAXREQUEST': '_viewRoot',
            'fPP:numProcesso-inputNumeroProcessoDecoration:numProcesso-inputNumeroProcesso': '',
            'mascaraProcessoReferenciaRadio': 'on',
            'fPP:j_id158:processoReferenciaInput': '',
            'fPP:dnp:nomeParte': '',
            'fPP:j_id176:nomeAdv': '',
            'fPP:j_id185:classeProcessualProcessoHidden': '',
            'tipoMascaraDocumento': 'on',
            'fPP:dpDec:documentoParte': cnpj_fmt,
            'fPP:Decoration:numeroOAB': '',
            'fPP:Decoration:j_id220': '',
            'fPP:Decoration:estadoComboOAB': 'org.jboss.seam.ui.NoSelectionConverter.noSelectionValue',
            'fPP': 'fPP',
            'autoScroll': '',
            'javax.faces.ViewState': 'j_id1',
            'fPP:j_id226': 'fPP:j_id226',
            'AJAX:EVENTS_COUNT': '1'
        }

        session = req.Session()
        uri = 'https://pje1g.trf6.jus.br/consultapublica/ConsultaPublica/listView.seam'
        res = req.get(uri)
        res.cookies

        cookies = dict(res.cookies)
        
        uri_param = ';jsessionid=' + cookies['JSESSIONID']
        post_uri = uri + uri_param
        post_uri
        
        res = req.post(post_uri, data=data, timeout=10)
        res.text
        
        soup = bs(res.text, features='lxml')
        if soup.find(string='Sua pesquisa não encontrou nenhum processo disponível.'):
            return []
        links = soup.find_all('a', attrs={'title': 'Ver Detalhes'})
        urls = [link.attrs['onclick'] for link in links]
        urls = [self.limpa_url(url) for url in urls]
        return urls

    def extrai_num_processo(self, soup):
        parent_div = soup.find(id='j_id141:processoTrfViewView:j_id147')
        target = parent_div.find('div', attrs={'class': 'col-sm-12'})
        text = target.get_text().strip()
        return text

    def extrai_classe(self, soup):
        parent_div = soup.find(id='j_id141:processoTrfViewView:j_id170')
        target = parent_div.find('div', attrs={'class': 'col-sm-12'})
        text = target.get_text().strip()
        text = re.sub(r'[\n]+', ' | ', text)
        return text

    def extrai_assunto(self, soup):
        parent_div = soup.find(id='j_id141:processoTrfViewView:j_id181')
        target = parent_div.find('div', attrs={'class': 'col-sm-12'})
        text = target.get_text().strip()
        text = re.sub(r'[\n]+', ' | ', text)
        return text

    def extrai_exequente(self, soup):
        exequente = soup.find('span', attrs={'id': 'j_id141:processoPartesPoloAtivoResumidoTableBinding:0:j_id288'})
        exequente = exequente.get_text().strip()
        exequente = re.sub(r'[\n]+', ' | ', exequente)
        return exequente

    def extrai_executado(self, soup):
        executado = soup.find('span', attrs={'id': 'j_id141:processoPartesPoloPassivoResumidoTableBinding:0:j_id353'})
        executado = executado.get_text().strip()
        executado = re.sub(r'[\n]+', ' | ', executado)
        return executado

    def extrai_atualizacao(self, soup):
        atualizacao = soup.find(id='j_id141:processoEvento:0:j_id505').get_text().strip()
        return atualizacao

    def extrai_processos_info(self, res):
        soup = bs(res.text, features='lxml')
        valores = {
            'Número Processo': self.extrai_num_processo(soup),
            'Classe': self.extrai_classe(soup),
            'Assuntos': self.extrai_assunto(soup),
            'Exequente': self.extrai_exequente(soup),
            'Executado': self.extrai_executado(soup),
            'Ultima Atualização': self.extrai_atualizacao(soup),
            'Link para o processo': res.url
        }
        return valores

    def scrape(self, urls: List[str]):
        dados = {}
        for processo in urls:
            res = req.get(processo, timeout=5)
            valores = self.extrai_processos_info(res)
            for key, value in valores.items():
                if key not in dados:
                    dados[key] = []
                dados[key].append(value)
            sleep(0.6)
        self.dados = dados
        return dados

    @staticmethod
    def formata_cnpj(cnpj):
        cnpj = cnpj[:2] + '.' + cnpj[2:5] + '.' + cnpj[5:8] + '/' + cnpj[8:12] + '-' + cnpj[-2:]
        return cnpj

if __name__ == '__main__':
    cnpj = '70928650000187'
    scrapper = ScrapperTRF6()
    urls = scrapper.get_urls(cnpj)
    dados = scrapper.scrape(urls)

