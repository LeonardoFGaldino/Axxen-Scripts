import requests as req
from bs4 import BeautifulSoup as bs
from time import sleep
import re
from typing import List
from scrapper.utils.utils import ExcelWriter


class ScrapperTRF3:
    uri = 'https://pje1g.trf3.jus.br/pje/ConsultaPublica/listView.seam'
    headers = {
        'authority': 'pje1g.trf3.jus.br',
        'accept': '*/*',
        'accept-language': 'pt-PT,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'cache-control': 'no-cache',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'origin': 'https://pje1g.trf3.jus.br',
        'pragma': 'no-cache',
        'referer': 'https://pje1g.trf3.jus.br/pje/ConsultaPublica/listView.seam',
        'sec-ch-ua': '"Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
    }

    @staticmethod
    def limpa_url(url):
        url = url.strip('openPopUp(\'Consulta pública\',\'').strip('\')')
        url = 'https://pje1g.trf3.jus.br' + url
        return url

    def get_urls(self, cnpj):
        headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
        }
        cnpj_fmt = self.formata_cnpj(cnpj)
        data = {
            'AJAXREQUEST': '_viewRoot',
            'fPP:numProcesso-inputNumeroProcessoDecoration:numProcesso-inputNumeroProcesso': '',
            'mascaraProcessoReferenciaRadio': 'on',
            'fPP:j_id147:processoReferenciaInput': '',
            'fPP:dnp:nomeParte': '',
            'fPP:j_id165:nomeAdv': '',
            'fPP:j_id174:classeProcessualProcessoHidden': '',
            'tipoMascaraDocumento': 'on',
            'fPP:dpDec:documentoParte': cnpj_fmt,
            'fPP:Decoration:numeroOAB': '',
            'fPP:Decoration:j_id209': '',
            'fPP:Decoration:estadoComboOAB': 'org.jboss.seam.ui.NoSelectionConverter.noSelectionValue',
            'fPP': 'fPP',
            'autoScroll': '',
            'javax.faces.ViewState': 'j_id1',
            'fPP:j_id215': 'fPP:j_id215 ',
            'AJAX:EVENTS_COUNT': '1',
        }
        session = req.Session()
        res = session.get(self.uri, headers=headers, timeout=5)

        cookies = dict(session.cookies)
        res = req.post(self.uri, data=data, cookies=cookies, headers=self.headers, timeout=5)
        soup = bs(res.text, features='lxml')
        if soup.find(string='Sua pesquisa não encontrou nenhum processo disponível.'):
            return []
        links = soup.find_all('a', attrs={'title': 'Ver Detalhes'})
        urls = [link.attrs['onclick'] for link in links]
        urls = [self.limpa_url(url) for url in urls]
        return urls

    def extrai_num_processo(self, soup):
        parent_div = soup.find(id='j_id131:processoTrfViewView:j_id137')
        target = parent_div.find('div', attrs={'class': 'col-sm-12'})
        text = target.get_text().strip()
        return text

    def extrai_classe(self, soup):
        parent_div = soup.find(id='j_id131:processoTrfViewView:j_id160')
        target = parent_div.find('div', attrs={'class': 'col-sm-12'})
        text = target.get_text().strip()
        text = re.sub(r'[\n]+', ' | ', text)
        return text

    def extrai_assunto(self, soup):
        parent_div = soup.find(id='j_id131:processoTrfViewView:j_id171')
        target = parent_div.find('div', attrs={'class': 'col-sm-12'})
        text = target.get_text().strip()
        text = re.sub(r'[\n]+', ' | ', text)
        return text

    def extrai_exequente(self, soup):
        exequente = soup.find('span', attrs={'id': 'j_id131:processoPartesPoloAtivoResumidoList:0:j_id278'})
        exequente = exequente.get_text().strip()
        exequente = re.sub(r'[\n]+', ' | ', exequente)
        return exequente

    def extrai_executado(self, soup):
        executado = soup.find('span', attrs={'id': 'j_id131:processoPartesPoloPassivoResumidoList:0:j_id342'})
        executado = executado.get_text().strip()
        executado = re.sub(r'[\n]+', ' | ', executado)
        return executado

    def extrai_atualizacao(self, soup):
        atualizacao = soup.find(id='j_id131:processoEvento:0:j_id492').get_text().strip()
        return atualizacao

    def extrai_processos_info(self, res):
        soup = bs(res.text, features='lxml')
        valores = {
            'Número Processo': self.extrai_num_processo(soup),
            'Classe': self.extrai_classe(soup),
            'Assuntos': self.extrai_assunto(soup),
            'Exequente': self.extrai_exequente(soup),
            'Executado': self.extrai_executado(soup),
            'Ultima Atualização': self.extrai_atualizacao(soup),
            'Link para o processo': res.url
        }
        return valores

    def scrape(self, urls: List[str]):
        dados = {}
        for processo in urls:
            res = req.get(processo, headers=self.headers, timeout=5)
            valores = self.extrai_processos_info(res)
            for key, value in valores.items():
                if key not in dados:
                    dados[key] = []
                dados[key].append(value)
            sleep(0.6)
        self.dados = dados
        return dados

    @staticmethod
    def formata_cnpj(cnpj):
        cnpj = cnpj[:2] + '.' + cnpj[2:5] + '.' + cnpj[5:8] + '/' + cnpj[8:12] + '-' + cnpj[-2:]
        return cnpj


if __name__ == '__main__':
    cnpj = '06160091000109'
    scrapper = ScrapperTRF3()
    excel_writer = ExcelWriter()
    urls = scrapper.get_urls(cnpj)
    dados = scrapper.scrape(urls)
    csv = excel_writer.dict_to_csv(dados)
    open(f'relatorio_processos_{cnpj}.csv', 'w').write(csv)








