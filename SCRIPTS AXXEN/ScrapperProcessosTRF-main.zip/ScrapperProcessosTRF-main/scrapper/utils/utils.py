from typing import List

class ExcelWriter:
    def dict_to_csv(self, dados: dict) -> str:
        headers = dados.keys()
        body = list(zip(*dados.values()))
        body.insert(0, headers)
        csv = '\n'.join(';'.join(row) for row in body)
        return csv
