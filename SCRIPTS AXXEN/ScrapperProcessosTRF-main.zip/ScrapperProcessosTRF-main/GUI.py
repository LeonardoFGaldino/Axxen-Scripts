from scrapper.ScrapperTRF1 import ScrapperTRF1
from scrapper.ScrapperTRF2 import ScrapperTRF2
from scrapper.ScrapperTRF3 import ScrapperTRF3
# from scrapper.ScrapperTRF4 import ScrapperTRF4
# from scrapper.ScrapperTRF5 import ScrapperTRF5
from scrapper.ScrapperTRF6 import ScrapperTRF6
from scrapper.utils.utils import ExcelWriter
from tkinter import PhotoImage, Label
import tkinter as tk
from tkinter import messagebox
from tkinter import filedialog as fd
from tkinter import ttk
from typing import List
from threading import Thread


class IterablePB:
    def __init__(self, master, iterable:List):
        self._i = iterable
        self._master = master
        self._status = tk.DoubleVar()
        self._status.set(0)

    def __iter__(self):
        pb_window = tk.Toplevel(
            master=self._master
        )
        pb_label = tk.Label(
            master=pb_window,
            text='Buscando:'
        )
        pb = ttk.Progressbar(
            master=pb_window,
            variable=self._status,
            mode='determinate'
        )
        pb_label.pack()
        pb.pack()
        #pb_window.update_idletasks()
        for idx, element in enumerate(self._i):
            if not pb_window.winfo_exists():
                break
            yield element
            progress = (idx+1) / len(self._i) * 100
            self._status.set(progress)
            pb_window.update_idletasks()
        pb_window.destroy()

class ScrapperGUI:
    scrappers = {
        'TRF-1': ScrapperTRF1(),
        'TRF-2': ScrapperTRF2(),
        'TRF-3': ScrapperTRF3(),
        # 'TRF-4': ScrapperTRF4(),
        # 'TRF-5': ScrapperTRF5(),
        'TRF-6': ScrapperTRF6()
    }
    excel_writer = ExcelWriter()

    def __init__(self, master):
        self._master = master
        self._master.title("Web Scraper Interface")

        tk.Label(root, text=" ", bg="#333333").pack()
        tk.Label(root, text=" ", bg="#333333").pack()
        
        # Combobox Região
        self._regiao = tk.StringVar()
        box_label = tk.Label(
            master=self._master,
            text='Região:', bg="#333333", font=("Roboto", 15), fg="white"
        )
        box = ttk.Combobox(
            master=self._master,
            values=['TRF-1', 'TRF-2', 'TRF-3', 'TRF-6'],
            textvariable=self._regiao
        )
        box_label.pack()
        box.pack()

        # Entry CNPJ
        self._cnpj_var = tk.StringVar()
        cnpj_label = tk.Label(
            master=self._master,
            text='CNPJ:', bg="#333333", font=("Roboto", 15), fg="white"
        )
        cnpj_entry = tk.Entry(
            master=self._master,
            textvariable=self._cnpj_var
        )
        cnpj_label.pack()
        cnpj_entry.pack()
        tk.Label(root, text=" ", bg="#333333").pack()
        tk.Label(root, text=" ", bg="#333333").pack()

        # Botão Buscar
        search_button = tk.Button(
            master=self._master,
            text='Buscar', font=("Roboto", 13), bg="#1D8C83", fg="#ffffff", border="5",
            command=lambda: self.scrape()
        )
        search_button.pack()
    
    def _scrape(self):
        regiao = self._regiao.get()
        cnpj = self._cnpj_var.get()
        if not regiao or not cnpj:
            messagebox.showerror('Erro', 'Preencha todos os campos.')
            return
        scrapper = self.scrappers[regiao]
        urls = scrapper.get_urls(cnpj=cnpj)        
        urls = IterablePB(master=self._master, iterable=urls)
        
        dados = scrapper.scrape(urls)
        if dados:
            output_file = fd.asksaveasfilename(
                defaultextension=".csv",
                title='Salvar arquivo',
                filetypes=(("Arquivo CSV","*.csv"), ("All Files", "*.*")),
                confirmoverwrite=True
            )
            
            csv = self.excel_writer.dict_to_csv(dados)
            open(output_file, 'w').write(csv)
            tk.messagebox.showinfo('Sucesso', f'Resultados salvos em {output_file}')
        else:
            tk.messagebox.showwarning('Aviso', 'Nenhum resultado encontrado.')
    
    def scrape(self):
        thread = Thread(target=lambda: self._scrape()) 
        thread.start()      

if __name__ == '__main__':
    root = tk.Tk()
    img = PhotoImage(file="axxenoficial.png")
    label_imagem = Label(root, image=img, bg="#333333").pack()
    root.geometry("600x600")
    root.configure(bg="#333333")
    direitos_autorais = tk.Label(root, text="© 2023 Axxen. Todos os direitos reservados.", font=("Arial", 10), bg="#333333", fg="white")
    direitos_autorais.pack(side="bottom")
    ScrapperGUI(root)
    root.mainloop()

# CNPJ TRF3 --> 06160091000109
# CNPJ TRF2 --> 02039540000104